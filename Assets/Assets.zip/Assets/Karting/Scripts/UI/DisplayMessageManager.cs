﻿using UnityEngine;

public class DisplayMessageManager : MonoBehaviour
{
    public UITable DisplayMessageRect;
}
